package com.example.thread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String str="";
    TextView text1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1= (TextView) findViewById(R.id.text1);

        //Вариант с использованием интерфейса Runnable лучше применять, когда не нужно
        // наследовать от класса Thread ничего лишнего, а только реализовать метод run().
        Thread thread=new Thread(new AnotherRunnable());
        thread.start();

        //AnotherThread anotherThread=new AnotherThread();
        //anotherThread.start();
    }

    /*
    //Класс может наследовать от другого класса, если это необходимо
    class AnotherThread extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < 10; i++) {
                try{
                    Thread.sleep(1000); //Приостанавливает поток на 1 секунду
                } catch(InterruptedException e) {}
                str = str + "2";
            }
        }
    }
    */

    class AnotherRunnable implements Runnable {
        @Override
        public void run() {
            for (int i = 0; i < 10; i++) {
                try{
                   Thread.sleep(1000); //Приостанавливает поток на 1 секунду
                } catch(InterruptedException e) {}
                str = str + "3";
            }
        }
    }

    public void clickRefresh(View view) {
        System.out.println("str = " + str);
        text1.setText(str);
    }
}