package ru.myitschool.mte;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import ru.myitschool.mte.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private int click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.content.ibCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                click++;
                click = click % 3;
                binding.content.ibCar.setImageResource(R.drawable.car1 + click);
            }
        });
    }
}
