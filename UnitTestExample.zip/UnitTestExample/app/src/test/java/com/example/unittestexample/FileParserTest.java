package com.example.unittestexample;

import org.junit.Assert;
import org.junit.Test;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileParserTest {
    private static final File testFile = new File("test_file");

    FileParser fileParser = new FileParser(testFile);

    @Test
    public void getName_isPiter() {
        try {
            FileWriter writer = new FileWriter(testFile);
            writer.write("Piter");
            writer.close();
        } catch (IOException e) {
            System.out.println("Data write error");
        }

        String name = fileParser.getName();
        Assert.assertEquals(name, "Piter");

       testFile.delete();
    }

    @Test
    public void getName_isNotBob() {
        try {
            FileWriter writer = new FileWriter(testFile);
            writer.write("Piter");
            writer.close();
        } catch (IOException e) {
            System.out.println("Data write error");
        }

        String name = fileParser.getName();
        Assert.assertNotEquals(name, "Bob");

        testFile.delete();
    }
}
