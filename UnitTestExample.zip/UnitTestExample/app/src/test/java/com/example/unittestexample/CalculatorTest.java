package com.example.unittestexample;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculatorTest {
    @Test
    public void testSum() {
        Calculator calc = new Calculator();
        assertEquals(7, calc.sum(3, 4));
    }

    @Test
    public void testDiff() {
        Calculator calc = new Calculator();
        assertEquals(4, calc.diff(6, 2));
    }
}
