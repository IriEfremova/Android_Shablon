package com.example.unittestexample;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Test;

public class CalculatorTest {
    Calculator calc = new Calculator();

    //Проверяем, что выполнение метода sum вернет правильный результат
    @Test
    public void testSum() {
        Assert.assertEquals(7, calc.sum(3, 4));
    }

    @Test
    public void testDiff() {
        Assert.assertEquals(4, calc.diff(6, 2));
    }

    //Проверяем, что выполнение метода multi вернет правильный результат
    @Test
    public void testMulti() {
        //Так как метод умножения вызывает метод суммы, то с помощью класса Assume можно сделать
        //сначала проверку работы метода сложения
        Assume.assumeTrue(calc.sum(3,4) == 7);
        //Если проверка сложения провалилась, то тест дальше проводится не будет
        Assert.assertEquals(3, calc.multi(3, 1));
    }

}
