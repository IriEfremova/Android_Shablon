package com.example.unittestexample;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sumBtn = findViewById(R.id.sum_btn);
        sumBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText num1 = findViewById(R.id.num1_et);
                EditText num2 = findViewById(R.id.num2_et);
                TextView tv = findViewById(R.id.num1_et);
                int a = Integer.valueOf(num1.getText().toString());
                int b = Integer.valueOf(num2.getText().toString());
                ((TextView)findViewById(R.id.equal_tv)).setText(String.valueOf(a + b));
            }
        });
    }
}