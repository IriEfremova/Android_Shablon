package com.example.unittestexample;

/* Класс пользователя для теста */
public class User {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
