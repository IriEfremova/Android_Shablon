package com.example.unittestexample;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileParser {
    private final File file;

    public FileParser(File file) {
        this.file = file;
    }

    public String getName() {
        User user = new User();
        user.setName(readFile());
        return user.getName();
    }

    public String readFile() {
        try{
            String text = new String(Files.readAllBytes(Paths.get(file.getName())));
            return text;
        }
        catch (IOException e){
            System.out.println("Data read error");
        }
        return "";
    }

}
