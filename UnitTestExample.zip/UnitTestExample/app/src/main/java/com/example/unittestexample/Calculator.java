package com.example.unittestexample;

/* Класс математических функций */
public class Calculator {
    public int sum(int a, int b) {
        return a + b;
    }

    public int diff(int a, int b) {
        return a - b;
    }

    /* Умножение специально реализовано через метод сложения, чтобы показать пример использования Assume */
    public int multi(int a, int b) {
        for(int i = 1; i < b; i++)
            a = sum(a,a);
        return a;
    }
}
