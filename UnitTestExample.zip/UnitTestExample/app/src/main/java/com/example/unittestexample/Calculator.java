package com.example.unittestexample;

public class Calculator {
    public int sum(int a, int b) {
        return a + b;
    }

    public int diff(int a, int b) {
        return a - b;
    }
}
