package com.example.unittestexample;


import static androidx.test.espresso.action.ViewActions.click;

import android.content.Context;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.ViewAssertion;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.regex.Matcher;

/* Инструментальный тест для главной активности. При его запуске автоматически на мобильном устройстве
* запускается приложение, автоматически вводятся данные, нажимается кнопка и сравнивается результат
*/
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityScenarioRule<MainActivity> activityTestRule = new ActivityScenarioRule<>(
            MainActivity.class);

    @Test
    public void checkClick() {
        //В поле первого числа вводится 5
        Espresso.onView(ViewMatchers.withId(R.id.num1_et))
                .perform(ViewActions.typeText("5"));

        //В поле второго числа вводится 6
        Espresso.onView(ViewMatchers.withId(R.id.num2_et))
                .perform(ViewActions.typeText("6"));

        //Нажимается кнопка суммы
        Espresso.onView(ViewMatchers.withId(R.id.sum_btn))
                .perform(click());

        //Проверяем, что в поле результаты будет число 11
        Espresso.onView(ViewMatchers.withId(R.id.equal_tv))
                .check(ViewAssertions.matches(ViewMatchers.withText("11")));


    }
}
