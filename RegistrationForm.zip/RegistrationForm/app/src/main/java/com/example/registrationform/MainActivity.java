package com.example.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView photo = findViewById(R.id.iv_Photo);
        TextInputEditText firstName = findViewById(R.id.tv_FirstName);
        TextInputEditText lastName = findViewById(R.id.tv_LastName);
        TextInputEditText phone = findViewById(R.id.tv_Phone);
        RadioButton btnMale = findViewById(R.id.rbtn_Male);
        RadioButton btnFemale = findViewById(R.id.rbtn_Female);
        Button btnConfirm = findViewById(R.id.btn_Confirm);

        photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent(Intent.ACTION_PICK);
                galleryIntent.setType("image/*");
                startActivity(galleryIntent);
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MaterialAlertDialogBuilder(MainActivity.this)
                        .setTitle(R.string.update_profile)
                        .setMessage(R.string.msg_update_profile)
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Update Profile is OK", Toast.LENGTH_LONG).show();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, getResources().getString(R.string.no_update_profile), Toast.LENGTH_LONG).show();
                            }
                        })
                        .show();
            }
        });

    }

}