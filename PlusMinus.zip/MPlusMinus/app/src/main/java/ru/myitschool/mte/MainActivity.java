package ru.myitschool.mte;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import ru.myitschool.mte.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.content.tvResult.setText("0");
        binding.content.btPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number++;
                binding.content.tvResult.setText(String.valueOf(number));
            }
        });

        binding.content.btMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number--;
                binding.content.tvResult.setText(String.valueOf(number));
            }
        });
    }
}
