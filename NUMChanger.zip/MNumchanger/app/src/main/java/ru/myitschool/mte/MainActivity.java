package ru.myitschool.mte;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import ru.myitschool.mte.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private int currentIndex = 0;
    private ActivityMainBinding binding;
    private TextUpdatingThread thread;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(thread != null && thread.isRunning())
                    return;

                thread = new TextUpdatingThread();
                thread.start();
            }
        });

        binding.buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!thread.isRunning())
                    return;
                //Останавливаем поток
                thread.stopTimer();
                currentIndex = 0;
            }
        });
    }

    private void UpdateText(){
        binding.numIteration.setText(String.valueOf(currentIndex % 3 + 1));
        currentIndex++;
    }

    class TextUpdatingThread extends Thread {
        private boolean isRun = true;

        @Override
        public void run() {
            while (isRun) {
                try {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            UpdateText();
                        }
                    });
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        //Метод для остановки работы потока
        public void stopTimer(){
            isRun = false;
        }

        //Возвращает признак работы потока
        public boolean isRunning(){
            return isRun;
        }
    }
}
