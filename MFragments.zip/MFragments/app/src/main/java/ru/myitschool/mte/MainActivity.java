package ru.myitschool.mte;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import ru.myitschool.mte.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private FragmentChangerThread thread; //поток
    private int currentIndex; //номер текущего фрагмента

    //Массив фрагментов для смены. Через массив проще реализовать смену по индексу
    Fragment[] fragmentsArray = {new FirstFragment(), new ProceedingFragment()};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.content.startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(thread != null && thread.isRunning())
                    return;

                //Создаем и запускаем отдельный поток
                thread = new FragmentChangerThread();
                thread.start();
            }
        });

        binding.content.stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!thread.isRunning())
                    return;
                //Останавливаем поток
                thread.stopTimer();
            }
        });
    }

    //Смена фрагментов
    private void ChangeFragmment(){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        //Увеличиваем индекс текущего фрагмента на 1 и зацикливаем его
        transaction.replace(R.id.output_fragment,fragmentsArray[currentIndex++ % 2]);
        transaction.commit();
    }

    //Класс отдельного потока, который запускает смену фрагментов
    class FragmentChangerThread extends Thread {
        //Флажок, отвечающий за время работы потока
        private boolean isRun = true;

        @Override
        public void run() {
            while (isRun) {
                try {
                    //Смену фрагментов запускаем в UI потоке
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ChangeFragmment();
                        }
                    });
                    //Пауза на 3 секунды
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        //Метод для остановки работы потока
        public void stopTimer(){
            isRun = false;
        }

        //Возвращает признак работы потока
        public boolean isRunning(){
            return isRun;
        }
    }

}



