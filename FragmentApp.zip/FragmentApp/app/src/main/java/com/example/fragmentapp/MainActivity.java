package com.example.fragmentapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements FragmentChanger{
    FirstFragment firstFragment = new FirstFragment();
    SecondFragment secondFragment = new SecondFragment();
    FragmentManager fragmentManager = getSupportFragmentManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.add(R.id.main_frag, firstFragment);
        transaction.add(R.id.main_frag, secondFragment);
        transaction.hide(secondFragment);

        transaction.commit();
    }

    @Override
    public void fragmentChange(String name, int number) {
        if(number == 0){
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.hide(secondFragment);
            fragmentTransaction.show(firstFragment);
            fragmentTransaction.commit();
        }
        if(number == 1){
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.hide(firstFragment);
            secondFragment.setUserName(name);
            fragmentTransaction.show(secondFragment);
            fragmentTransaction.commit();
        }
    }
}