package com.example.fragmentapp;

public interface FragmentChanger {
    public void fragmentChange(String name, int number);
}
