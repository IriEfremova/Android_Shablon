package com.example.funnybirds;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.CountDownTimer;
import android.view.SurfaceHolder;

public class DrawThread extends Thread{
    private SurfaceHolder surfaceHolder;
    private boolean running = true;
    private Paint backPaint = new Paint();
    private int viewWidth;
    private int viewHeight;
    private int points;
    private Sprite playerBird;
    private Sprite enemyBird;
    private final int timerInterval = 30;
    Paint p = new Paint();

    {
        backPaint.setColor(Color.BLUE);
        backPaint.setStyle(Paint.Style.FILL);
        p.setAntiAlias(true);
        p.setTextSize(55.0f);
        p.setColor(Color.WHITE);
    }

    class Timer extends CountDownTimer {
        public Timer() {
            super(Integer.MAX_VALUE, timerInterval);
        }
        @Override
        public void onTick(long millisUntilFinished) {
            update();
        }
        @Override
        public void onFinish() {
        }
    }

    public DrawThread(Context context, SurfaceHolder surfaceHolder) {
        this.surfaceHolder = surfaceHolder;

        Bitmap b = BitmapFactory.decodeResource(context.getResources(), R.drawable.player);
        int w = b.getWidth()/5;
        int h = b.getHeight()/3;
        Rect firstFrame = new Rect(0, 0, w, h);
        playerBird = new Sprite(10, 0, 0, 100, firstFrame, b);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                if (i == 0 && j == 0) {
                    continue;
                }
                if (i == 2 && j == 3) {
                    continue;
                }
                playerBird.addFrame(new Rect(j * w, i * h, j * w + w, i * w + w));
            }
        }

        b = BitmapFactory.decodeResource(context.getResources(), R.drawable.enemy);
        w = b.getWidth()/5;
        h = b.getHeight()/3;
        firstFrame = new Rect(4*w, 0, 5*w, h);
        enemyBird = new Sprite(2000, 250, -300, 0, firstFrame, b);
        for (int i = 0; i < 3; i++) {
            for (int j = 4; j >= 0; j--) {
                if (i ==0 && j == 4) {
                    continue;
                }
                if (i ==2 && j == 0) {
                    continue;
                }
                enemyBird.addFrame(new Rect(j*w, i*h, j*w+w, i*w+w));
            }
        }

        Timer t = new Timer();
        t.start();
    }

    protected void update () {
        playerBird.update(timerInterval);
        enemyBird.update(timerInterval);

        if (playerBird.getY() + playerBird.getFrameHeight() > viewHeight) {
            playerBird.setY(viewHeight - playerBird.getFrameHeight());
            playerBird.setVy(-playerBird.getVy());
            points--;
        }
        else if (playerBird.getY() < 0) {
            playerBird.setY(0);
            playerBird.setVy(-playerBird.getVy());
            points--;
        }

        if (enemyBird.getX() < - enemyBird.getFrameWidth()) {
            teleportEnemy ();
            points +=10;
        }

        // Проверка столкновений
        if (enemyBird.intersect(playerBird)) {
            teleportEnemy ();
            points -= 40;
        }
    }

    private void teleportEnemy () {
        enemyBird.setX(viewWidth + Math.random() * 500);
        enemyBird.setY(Math.random() * (viewHeight - enemyBird.getFrameHeight()));
    }

    public void setSize(int widht, int height){
        viewWidth = widht;
        viewHeight = height;
    }

    public void requestStop(){
        running = false;
    }

    public void setPlayerBirdPosition(float x, float y){
        // Движение вверх
        if (y < playerBird.getBoundingBoxRect().top) {
            playerBird.setVy(-500);
            points--;
        }
        else if (y > (playerBird.getBoundingBoxRect().bottom)) {
            playerBird.setVy(500);
            points--;
        }
    }

    @Override
    public void run() {
        while(running){
            Canvas canvas = surfaceHolder.lockCanvas();
            if(canvas != null){
                try{
                    canvas.drawRect(0,0, canvas.getWidth(), canvas.getHeight(), backPaint);
                    playerBird.draw(canvas);
                    enemyBird.draw(canvas);
                    canvas.drawText(points+"", viewWidth - 100, 70, p);
                }
                finally {
                    surfaceHolder.unlockCanvasAndPost(canvas);
                }

            }
        }
    }
}
