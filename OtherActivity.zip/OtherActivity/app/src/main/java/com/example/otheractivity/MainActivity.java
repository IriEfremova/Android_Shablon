package com.example.otheractivity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvResult;

    ActivityResultLauncher<Intent> otherActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    //Возврат результата работы второй активности
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        //Вытаскиваем данные по метке "UserName" и отображаем их в поле результата
                        tvResult.setText(data.getStringExtra("UserName"));
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.textResult);

        Button btnStart = findViewById(R.id.button_start);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Простой запуск активности без ожидания результата от нее
                Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
                startActivity(intent);
            }
        });

        Button btnStartResult = findViewById(R.id.button_start_result);
        btnStartResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Запуск активности с ожиданием результата ее работы
                Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                otherActivityResultLauncher.launch(intent);
            }
        });
    }
}